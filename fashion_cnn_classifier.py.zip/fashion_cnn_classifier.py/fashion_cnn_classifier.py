
import numpy as np
import tensorflow as tf
from keras.datasets import fashion_mnist
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.utils import to_categorical
import matplotlib.pyplot as plt

# Load the Fashion MNIST dataset
# Returns: (x_train, y_train), (x_test, y_test)
(x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()

# Define the class names for prediction display (from your provided image)
class_names = [
    'T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
    'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot'
]

print("Data Loaded.")
print(f"Training data shape: {x_train.shape}")
print(f"Test data shape: {x_test.shape}")

# --- A. Reshape Data for CNN ---
# CNN expects data in the format: (samples, height, width, channels)
# Fashion MNIST images are (28, 28) grayscale, so channels=1.
x_train = x_train.reshape((x_train.shape[0], 28, 28, 1))
x_test = x_test.reshape((x_test.shape[0], 28, 28, 1))

# --- B. Normalize Pixel Values ---
# Normalize to the range [0, 1]
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# --- C. One-Hot Encode Labels ---
# Convert labels (0-9) to one-hot vectors (e.g., 2 -> [0, 0, 1, 0, 0, 0, 0, 0, 0, 0])
y_train_encoded = to_categorical(y_train, num_classes=10)
y_test_encoded = to_categorical(y_test, num_classes=10)

print("Data Preprocessing Complete.")

# --- Model Definition ---
# The model must have six layers:
# 1. Conv2D
# 2. MaxPooling2D
# 3. Conv2D
# 4. MaxPooling2D
# 5. Flatten
# 6. Dense (Output)

model = Sequential([
    # Layer 1: Convolutional
    Conv2D(filters=32, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1), name='Conv1'),

    # Layer 2: Pooling
    MaxPooling2D(pool_size=(2, 2), name='Pool1'),

    # Layer 3: Convolutional
    Conv2D(filters=64, kernel_size=(3, 3), activation='relu', name='Conv2'),

    # Layer 4: Pooling
    MaxPooling2D(pool_size=(2, 2), name='Pool2'),

    # Layer 5: Flattening (prepares data for Dense layers)
    Flatten(name='Flatten'),
    
    # Optional: Add a Dropout layer to prevent overfitting (not strictly required 
    # as a layer type, but good practice. Sticking to the core six for simplicity.)
    # Dropout(0.5, name='Dropout'), 
    
    # Layer 6: Dense (Output Layer)
    # 10 units for 10 classes, softmax activation for probability distribution
    Dense(units=10, activation='softmax', name='Output')
])

# --- Compile Model ---
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy', # Used for one-hot encoded labels
    metrics=['accuracy']
)

print("\n--- Model Summary (6 Layers) ---")
model.summary()

# Train the model
print("\n--- Starting Model Training ---")

# Use a small validation split to monitor performance during training
history = model.fit(
    x_train, y_train_encoded,
    epochs=10,  # Training for 10 epochs
    batch_size=64,
    validation_split=0.1,
    verbose=1
)

# Evaluate the model on the test data
loss, accuracy = model.evaluate(x_test, y_test_encoded, verbose=0)
print(f"\nTest Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy*100:.2f}%")


# --- Prediction for at least two images ---
# 1. Select the first two images from the test set
sample_images = x_test[:2]
sample_labels = y_test[:2]

# 2. Make the predictions
predictions = model.predict(sample_images)

print("\n--- Predictions ---")

def display_prediction(index, predictions, true_labels, images):
    """Helper function to display image and prediction results."""
    # The prediction is a probability array; argmax gets the predicted class index
    predicted_class = np.argmax(predictions[index])
    true_class = true_labels[index]

    plt.imshow(images[index].reshape(28, 28), cmap='gray')
    plt.title(f"True: {class_names[true_class]} | Predicted: {class_names[predicted_class]}")
    plt.xlabel(f"Confidence: {np.max(predictions[index])*100:.2f}%")
    plt.axis('off')
    plt.show()

# Display results for Image 1
display_prediction(0, predictions, sample_labels, sample_images)
# Display results for Image 2
display_prediction(1, predictions, sample_labels, sample_images)

# For console output:
print(f"Image 1 (True Class: {class_names[sample_labels[0]]}) Predicted as: {class_names[np.argmax(predictions[0])]}")
print(f"Image 2 (True Class: {class_names[sample_labels[1]]}) Predicted as: {class_names[np.argmax(predictions[1])]}")


