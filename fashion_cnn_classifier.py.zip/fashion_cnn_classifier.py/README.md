
# Fashion MNIST Classification using 6-Layer CNN

This project implements a 6-layer Convolutional Neural Network (CNN) using Keras (TensorFlow) to classify the Fashion MNIST dataset, as required for the assignment.

## Prerequisites

To run the Python code, you need to have the following installed:

* **Python 3.x**
* **TensorFlow** (which includes Keras)
* **NumPy**
* **Matplotlib**

You can install the required Python dependencies using pip:
```bash
pip install tensorflow numpy matplotlib


File Structure
fashion_cnn_classifier.py: Contains the complete Python code for data loading, preprocessing, model definition (6 layers), training, and prediction.

README.md: This instruction file.

Execution Instructions
Save the script: Save the provided Python code as fashion_cnn_classifier.py.

Run the script:

Bash

python fashion_cnn_classifier.py



Output:

The script will print the model summary, training progress, and final test accuracy.

It will display two pop-up windows, each showing one sample image from the test set along with its True Label and the Model's Prediction and Confidence.

The console will also print the prediction results for the two sample images.